from django.contrib import admin
from django.urls import path
from api.views import studentview, studentlistview
urlpatterns = [
    path('admin/', admin.site.urls),
    path('student/<int:pk>/', studentview),
    path('student/', studentlistview)
]
